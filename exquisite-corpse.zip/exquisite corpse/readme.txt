Quick start

You will need to provide your OpenAI API key for the program to run. (You
thought I'd let you use mine? Ha! It costs money -- though not much.) To do so,
you can setup an account and obtain your key here:

https://platform.openai.com/signup

Once you have an OpenAI account, you can proceed to,

https://platform.openai.com/account/api-keys

And create a secret key. Then, open the .env file and replace "<your secret key here>"
with your key (in quotes)

By the way, the costs of generating text using ChatGPT is $0.002/thousand tokens (or
about 750 words). Unless you are seeking to outdo epics such as Dante's Inferno, the cost
will be negligble. A fraction of a penny for a poem.

Then run the app and collaborate on some poetry with ChatGPT! Basically,

1) Write a few stanzas, and click the "Fold" button. This is like folding the paper in the
   original surrealist's writing game.
2) ChatGPT receives the last line you wrote, and writes its contribution. (As if it folded
   the paper again). 
3) You will only see its last line of its contribution. Add your next lines from there.
4) Fold again.

Once you feel it is complete, click the "Reveal Poem" button. Marvel at the possibilities of
human/AI collaboration! You can save the result as a text folder using the File:Save menu.

Files included:

exquisite.exe -- Windows application of exquisite-corpse

instructions.txt -- These are the instructions for the model (ChatGPT).
		    It is the prompt engineering to tell it how to play the game.

gpt_config.json -- Model configuration in JSON format. This is where we can try 
                   different parameters such as temperature (which is one way to specify
                   how creative or random we want the model to be), or max_tokens, which
                   says how long we want to model to generate text.

.env -- Your secret API key for the model on OpenAI.

